package org.dant.tp1;

/*
 * @author Olivier Pitton <olivier@indexima.com> on 13/11/2020
 */

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class UserOutputStream extends FilterOutputStream {

	private final ObjectOutputStream out;

	public UserOutputStream(OutputStream out) throws IOException {
		super(out);
		this.out = new ObjectOutputStream(out);
	}

	public void writeUser(User user) throws IOException {
		out.writeObject(user);
	}

	@Override
	public void close() throws IOException {
		super.close();
		out.close();
	}
}
