package org.dant.tp1;

/*
 * @author Olivier Pitton <olivier@indexima.com> on 13/11/2020
 */

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Exercice1 {

	public static void main(String... args) throws Exception {
		// Create a file with some data to copy
		Files.write(Paths.get("input.txt"), "salut".getBytes("UTF-8"));
		copy("input.txt", "output.txt");
	}

	public static void copy(String input, String output) throws IOException {
		// Use try with resources to avoid calling close
		try(FileInputStream fis = new FileInputStream(input);
		    FileOutputStream fos = new FileOutputStream(output)) {
			int c;
			// Copy content from inputstream to outputstream
			while ((c = fis.read()) != -1) {
				fos.write(c);
			}
			fos.flush();
		}
	}

}
