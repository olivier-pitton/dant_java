package org.dant.tp1;

/*
 * @author Olivier Pitton <olivier@indexima.com> on 13/11/2020
 */

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;

public class UserInputStream extends FilterInputStream {

	private final ObjectInputStream in;

	public UserInputStream(InputStream in) throws IOException {
		super(in);

		this.in = new ObjectInputStream(in);
	}

	public User readUser() throws IOException, ClassNotFoundException {
		return (User) in.readObject();
	}

	@Override
	public void close() throws IOException {
		super.close();
		in.close();
	}
}
