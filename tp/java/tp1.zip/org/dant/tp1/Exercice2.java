package org.dant.tp1;

/*
 * @author Olivier Pitton <olivier@indexima.com> on 13/11/2020
 */

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Date;

public class Exercice2 {

	public static void main(String... args) throws Exception {
		readWriteObject("serial.data");
	}

	public static void readWriteObject(String filename) throws Exception {
		User user = new User("olivier", "123", new Date());
		try(ObjectOutputStream ois = new ObjectOutputStream(new FileOutputStream(filename))) {
			ois.writeObject(user);
		}

		try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
			User readUser = (User) ois.readObject();
			System.out.println(readUser);
		}
	}

}
